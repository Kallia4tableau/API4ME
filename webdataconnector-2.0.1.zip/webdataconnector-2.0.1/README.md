# Tableau Web Data Connector SDK
[![Coverage Status](https://coveralls.io/repos/github/jagreene/webdataconnector/badge.svg?branch=tests)](https://coveralls.io/github/jagreene/webdataconnector?branch=tests) [![Build Status](https://travis-ci.org/jagreene/webdataconnector.svg?branch=tests)](https://travis-ci.org/jagreene/webdataconnector)

Currently in development is version 2.0 of the web data connector API.

All of the information for this content can be found in our beta docs: [http://tableau.github.io/webdataconnector](http://tableau.github.io/webdataconnector/).

Please check out the new API! We would love feedback on it and the docs.
